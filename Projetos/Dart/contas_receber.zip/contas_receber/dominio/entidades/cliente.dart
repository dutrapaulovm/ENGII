class Cliente {
  int codigo = 0;
  String nome = "";
  String cpf = "";
}
