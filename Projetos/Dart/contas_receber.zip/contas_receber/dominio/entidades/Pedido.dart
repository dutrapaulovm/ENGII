class Pedido {
  int codPedido = 0;
  DateTime data = DateTime.now();
  int codCliente = 0;

  Pedido(this.codCliente, this.data);
}
