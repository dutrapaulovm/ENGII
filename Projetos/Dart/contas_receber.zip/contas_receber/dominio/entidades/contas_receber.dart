class ContasReceber {
  int codigo = 0;
  int codCliente = 0;
  DateTime emissao = DateTime.now();
  DateTime datavenc = DateTime.now();
  double valor = 0.0;
}
