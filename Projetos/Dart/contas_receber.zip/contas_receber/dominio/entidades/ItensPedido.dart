class ItensPedido {
  int codItensPedido = 0;
  int codPedido      = 0;
  int codProduto     = 0;
  double quantidade  = 0.0;
  double valor       = 0.0;
}