import '../entidades/cliente.dart';

class ClienteRepositorio {
  void inserir(Cliente cliente) {
    /*Colocar aqui o código para
    inserir o cliente
    */
  }

  void alterar(Cliente cliente) {
    //...
  }

  void excluir(int codigo) {}

  Cliente consultarCodigo(int codigo) {
    return Cliente();
  }

  List<Cliente> consultarTodos() {
    return [];
  }
}
