import 'dominio/entidades/cliente.dart';
import 'dominio/repositorio/cliente_repositorio.dart';

void main() {
  Cliente cl = Cliente();
  cl.codigo = 1;
  cl.cpf = "0000000000";
  cl.nome = "Paulo Vinicius";

  ClienteRepositorio clienteRep = ClienteRepositorio();

  clienteRep.inserir(cl);
}
